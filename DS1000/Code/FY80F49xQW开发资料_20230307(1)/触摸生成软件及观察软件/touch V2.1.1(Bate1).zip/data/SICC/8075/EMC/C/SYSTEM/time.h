#ifndef _TIME_H_
#define _TIME_H_
#include "cms80fx51x.h"


extern void TMR0_Config(void);

#endif
