#ifndef _TIME_H_
#define _TIME_H_
#include "cms80f761xx.h"


extern void TMR0_Config(void);

#endif
