#if	C_KCOUNT > 0
#pragma	ram	0x20-0x25
#endif

#if	C_KCOUNT > 1
#pragma	ram	0x26-0x2B
#endif

#if	C_KCOUNT > 2
#pragma	ram	0x2C-0x31
#endif

#if	C_KCOUNT > 3
#pragma	ram	0x32-0x37
#endif

#if	C_KCOUNT > 4
#pragma	ram	0x38-0x3D
#endif

#if	C_KCOUNT > 5
#pragma	ram	0x3E-0x43
#endif

#if	C_KCOUNT > 6
#pragma	ram	0x44-0x49
#endif

#if	C_KCOUNT > 7
#pragma	ram	0x4A-0x4F
#endif

#if	C_KCOUNT > 8
#pragma	ram	0x50-0x55
#endif

#if	C_KCOUNT > 9
#pragma	ram	0x56-0x5B
#endif

#if	C_KCOUNT > 10
#pragma	ram	0x5C-0x61
#endif

#if	C_KCOUNT > 11
#pragma	ram	0x62-0x67
#endif

#if	C_KCOUNT > 12
#pragma	ram	0x68-0x6D
#endif

#if	C_KCOUNT > 13
#pragma	ram	0x6E-0x73
#endif

#if	C_KCOUNT > 14
#pragma	ram	0x74-0x79
#endif

#if	C_KCOUNT > 15
#pragma	ram	0x7A-0x7F
#endif
;0X20-0X7F @ 16Key


#if	C_KCOUNT > 0
#pragma	ram	0xA0-0xA1
#endif

#if	C_KCOUNT > 1
#pragma	ram	0xA2-0xA3
#endif

#if	C_KCOUNT > 2
#pragma	ram	0xA4-0xA5
#endif

#if	C_KCOUNT > 3
#pragma	ram	0xA6-0xA7
#endif

#if	C_KCOUNT > 4
#pragma	ram	0xA8-0xA9
#endif

#if	C_KCOUNT > 5
#pragma	ram	0xAA-0xAB
#endif

#if	C_KCOUNT > 6
#pragma	ram	0xAC-0xAD
#endif

#if	C_KCOUNT > 7
#pragma	ram	0xAE-0xAF
#endif

#if	C_KCOUNT > 8
#pragma	ram	0xB0-0xB1
#endif

#if	C_KCOUNT > 9
#pragma	ram	0xB2-0xB3
#endif

#if	C_KCOUNT > 10
#pragma	ram	0xB4-0xB5
#endif

#if	C_KCOUNT > 11
#pragma	ram	0xB6-0xB7
#endif

#if	C_KCOUNT > 12
#pragma	ram	0xB8-0xB9
#endif

#if	C_KCOUNT > 13
#pragma	ram	0xBA-0xBB
#endif

#if	C_KCOUNT > 14
#pragma	ram	0xBC-0xBD
#endif

#if	C_KCOUNT > 15
#pragma	ram	0xBE-0xBF
#endif
;0XA0-0XBF @ 16Key


#if	C_KCOUNT > 0
#pragma	ram	0xC0-0xC1
#endif

#if	C_KCOUNT > 1
#pragma	ram	0xC2-0xC3
#endif

#if	C_KCOUNT > 2
#pragma	ram	0xC4-0xC5
#endif

#if	C_KCOUNT > 3
#pragma	ram	0xC6-0xC7
#endif

#if	C_KCOUNT > 4
#pragma	ram	0xC8-0xC9
#endif

#if	C_KCOUNT > 5
#pragma	ram	0xCA-0xCB
#endif

#if	C_KCOUNT > 6
#pragma	ram	0xCC-0xCD
#endif

#if	C_KCOUNT > 7
#pragma	ram	0xCE-0xCF
#endif

#if	C_KCOUNT > 8
#pragma	ram	0xD0-0xD1
#endif

#if	C_KCOUNT > 9
#pragma	ram	0xD2-0xD3
#endif

#if	C_KCOUNT > 10
#pragma	ram	0xD4-0xD5
#endif

#if	C_KCOUNT > 11
#pragma	ram	0xD6-0xD7
#endif

#if	C_KCOUNT > 12
#pragma	ram	0xD8-0xD9
#endif

#if	C_KCOUNT > 13
#pragma	ram	0xDA-0xDB
#endif

#if	C_KCOUNT > 14
#pragma	ram	0xDC-0xDD
#endif

#if	C_KCOUNT > 15
#pragma	ram	0xDE-0xDF
#endif
;0XC0-0XDF @ 16Key


#pragma	ram	0xE0
#if	C_KCOUNT > 1
#pragma	ram	0xE1

#endif
#if	C_KCOUNT > 2
#pragma	ram	0xE2

#endif
#if	C_KCOUNT > 3
#pragma	ram	0xE3

#endif
#if	C_KCOUNT > 4
#pragma	ram	0xE4

#endif
#if	C_KCOUNT > 5
#pragma	ram	0xE5

#endif
#if	C_KCOUNT > 6
#pragma	ram	0xE6

#endif
#if	C_KCOUNT > 7
#pragma	ram	0xE7
#endif

#if	C_KCOUNT > 8
#pragma	ram	0xE8
#endif

#if	C_KCOUNT > 9
#pragma	ram	0xE9
#endif

#if	C_KCOUNT > 10
#pragma	ram	0xEA
#endif

#if	C_KCOUNT > 11
#pragma	ram	0xEB
#endif

#if	C_KCOUNT > 12
#pragma	ram	0xEC
#endif

#if	C_KCOUNT > 13
#pragma	ram	0xED
#endif

#if	C_KCOUNT > 14
#pragma	ram	0xEE
#endif

#if	C_KCOUNT > 15
#pragma	ram	0xEF
#endif
;0XE0-0XEF @ 16Key

