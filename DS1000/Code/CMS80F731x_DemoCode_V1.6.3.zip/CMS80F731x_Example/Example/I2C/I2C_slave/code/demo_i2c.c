/*******************************************************************************
* Copyright (C) 2019 China Micro Semiconductor Limited Company. All Rights Reserved.
*
* This software is owned and published by CMS LLC.
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with CMS
* components. This software is licensed by CMS to be adapted only
* for use in systems utilizing CMS components. CMS shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. CMS is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/

/****************************************************************************/
/** \file demo_i2c.c
**
**  
**
**	History:
**	
*****************************************************************************/
/****************************************************************************/
/*	include files
*****************************************************************************/
#include "demo_i2c.h"

/****************************************************************************/
/*	Local pre-processor symbols('#define')
****************************************************************************/
#define			Addr_Slave		0x50

/****************************************************************************/
/*	Global variable definitions(declared in header file with 'extern')
****************************************************************************/

/****************************************************************************/
/*	Local type definitions('typedef')
****************************************************************************/

/****************************************************************************/
/*	Local variable  definitions('static')
****************************************************************************/

/****************************************************************************/
/*	Local function prototypes('static')
****************************************************************************/




/****************************************************************************/
/*	Function implementation - global ('extern') and local('static')
****************************************************************************/
/******************************************************************************
 ** \brief	 I2C_Config
 ** \param [in] 
 **            	
 ** \return  none
 ** \note  
 ******************************************************************************/
void I2C_Config(void)
{	
	/*
	 (1)����I2CͨѶʱ��
	 */	 
	I2C_ConfigCLK(15);							/*����ʱ��SYSCLK = 8MHz, I2CCLK =100K*/
	/*
	(2)����IO����
	*/
	 GPIO_SET_MUX_MODE(P00CFG, GPIO_P00_MUX_SCL);			/*SCL*/
	 GPIO_SET_MUX_MODE(P01CFG, GPIO_P01_MUX_SDA);	 		/*SDA*/	 
	 GPIO_SET_PS_MODE(PS_SDA,GPIO_P01);
	 GPIO_SET_PS_MODE(PS_SCL,GPIO_P00);	
	/*
	(3)����Slave��ַ
	*/
	I2C_SlaveAddressSet(Addr_Slave);
	
	/*
	 (4)����I2C��ģʽ
	 */
	 I2C_EnableSlaveMode();
	
	/*
	(5)�����жϷ�ʽ
	*/
	I2C_EnableInt();
	/*
	(6)�����ж����ȼ�
	*/
	IRQ_SET_PRIORITY(IRQ_I2C, IRQ_PRIORITY_LOW);
	/*
	(7)�������ж�
	*/	
	IRQ_ALL_ENABLE();	
}








