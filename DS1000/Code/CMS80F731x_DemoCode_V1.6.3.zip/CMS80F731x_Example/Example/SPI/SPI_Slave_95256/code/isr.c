/*******************************************************************************
* Copyright (C) 2019 China Micro Semiconductor Limited Company. All Rights Reserved.
*
* This software is owned and published by CMS LLC.
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with CMS
* components. This software is licensed by CMS to be adapted only
* for use in systems utilizing CMS components. CMS shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. CMS is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/

/****************************************************************************/
/** \file isr.c
**
** 
**
**	History:
**		
*****************************************************************************/
/****************************************************************************/
/*	include files
*****************************************************************************/
#include "cms80f731xx.h"

/****************************************************************************/
/*	Local pre-processor symbols('#define')
****************************************************************************/

/****************************************************************************/
/*	Global variable definitions(declared in header file with 'extern')
****************************************************************************/
extern u8 data_WR;
extern u8 data_RD[20];

/****************************************************************************/
/*	Local type definitions('typedef')
****************************************************************************/

/****************************************************************************/
/*	Local variable  definitions('static')
****************************************************************************/


/****************************************************************************/
/*	Local function prototypes('static')
****************************************************************************/


/****************************************************************************/
/*	Function implementation - global ('extern') and local('static')
****************************************************************************/


/******************************************************************************
 ** \brief	 SPI interrupt service function
 **			
 ** \param [in]  none   
 **
 ** \return none
 ******************************************************************************/
uint8_t i;
void SPI_IRQHandler(void)  interrupt SPI_VECTOR
{
	if(SPI_GetIntFlag())
	{
		if(SPI_GetTransferIntFlag())      
		{
			data_RD[data_WR]=SPDR;
			for(i=2;i>0;i--);
			SPDR	=	0x5a;								//send 0X5A to ack master
//			while(!(SPSR&0x80));			//if need slave to send two bytes, please open this sentence
//			SPDR	=	data_WR;					//if need slave to send two bytes, please open this sentence 	

			data_WR++;
		}
	}
	
}


